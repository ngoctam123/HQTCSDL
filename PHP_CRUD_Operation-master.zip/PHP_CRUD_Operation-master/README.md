# PHP_CRUD_Operation

To Execute this application just start the Xampp web server.
Execute index.php file in the browser at locahost.

For more information take this tutorial.
[Video Tutotrial](https://youtu.be/JZdMXUIMdQw)
